#include <iostream>
#include <string>
#include <cstdlib>
#include "hash_table.h"
using namespace std;

class Student {
public:
	string name;
	double gpa;
	string key;

	Student() {};

	Student(string name, double gpa, const string key) {
		this->name = name;
		this->gpa = gpa;
		this->key = key;
	}

	//*Must have function for object comparison implementation may vary
	string getKey() {
		return key;
	}

	void setKey(string newKey) {
		key = newKey;
	}

	//Must have function to print the object if you do not want to override default operator
	string print() {
		//return "Name : " + name + " GPA : " + std::to_string(gpa) + " Key : " + key;
		return name;
	}

};

/*
int main() {
	HashTable<Student *> *hashTable = new HashTable<Student *>(20);
	Student *student1 = new Student("Ahmet", 3.0, "ahmet");
	Student *student2 = new Student("Ayse", 3.1, "ay?e");
	Student *student3 = new Student("Mehmet", 3.2, "mehmet");
	Student *student4 = new Student("Fatma", 3.3, "fatma");
	Student *student5 = new Student("II. Fatma", 3.4, "fatma");
	Student *student6 = new Student("II. Ahmet", 3.5, "bhmdt");
	cout << "Students" << endl;
	cout << "Student 1 : " << student1->print() << endl;
	cout << "Student 2 : " << student2->print() << endl;
	cout << "Student 3 : " << student3->print() << endl;
	cout << "Student 4 : " << student4->print() << endl;
	cout << "Student 5 : " << student5->print() << endl;
	cout << "Student 6 : " << student6->print() << endl;
	cout << "Print empty hashtable" << endl;
	hashTable->printHashTable();
	cout << "Print after inserting student1" << endl;
	hashTable->insert(student1);
	hashTable->printHashTable();
	cout << "Insert Student 2,3 and 4" << endl;
	hashTable->insert(student2);
	hashTable->insert(student3);
	hashTable->insert(student4);
	hashTable->printHashTable();
	cout << "Print again" << endl;
	hashTable->printHashTable();
	cout << "Add Student5 and chain data" << endl;
	hashTable->insert(student5);
	hashTable->printHashTable();
	cout << "Add Student6 who has same key value with Student 1" << endl;
	cout << "Chain data again" << endl;
	hashTable->insert(student6);
	hashTable->printHashTable();
	cout << "Find Student 6" << endl;
	Student *student = hashTable->find(student6->getKey());
	if (student == NULL) {
		cout << "Searched value with key : " << student6->getKey() << " found NULL !" << endl;
	}
	else {
		cout << "Found Student Info : " << student->print() << endl;
	}
	cout << "Remove Student 6" << endl;
	hashTable->remove(student6->getKey());
	hashTable->printHashTable();
	cout << "Student 6 key : " << student6->getKey() << endl;
	cout << "Search a non-exist student" << endl;
	hashTable->find("chmct");
	system("pause");
	return 0;
}

*/