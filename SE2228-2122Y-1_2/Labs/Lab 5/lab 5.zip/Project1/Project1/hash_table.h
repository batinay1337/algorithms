#include <iostream>
#include <cstring>
#include "linklist.h"


using namespace std;

template<class T>
class HashTable {
public:
	LinkList<T> **table;
	string deletedMark = "*";
	int tableSize;

	HashTable(int tableSize) {
		this->tableSize = tableSize;
		table = new LinkList<T> *[tableSize];
		for (int index = 0; index < tableSize; index++) {
			table[index] = NULL;
		}
	}

	/*Hash Function: sum of the ASCII codes of the characters % TABLE_SIZE
	Note that returned Hash value is not unique*/
	int hash(string key) {
		int sum = 0;
		for (int index = 0; index < key.length(); ++index) {
			sum = sum + key[index];
		}
		return sum % tableSize;
	}

	//Produces new index in the array
	int rehash(int index) {
		return (index + 1) % tableSize;
	}

	T getData(int index, string key) {
		if (index >= 0 && index < tableSize) {
			if (table[index] != NULL) {
				//Iterate over list
				LinkListNode<T> *tempHead = table[index]->head;
				while (tempHead != NULL) {
					cout << "Searching with key : " << key << " next value is : " << tempHead->data->print() << endl;
					if (tempHead->data->getKey() == key) {
						return tempHead->data;
					}
					tempHead = tempHead->next;
				}
				return NULL;
			}
			else {
				return NULL;
			}

		}
		else {
			cout << "Index is out of bound !" << endl;
			return NULL;
		}
	}

	void printHashTable() {
		cout << "Hash Table " << endl;
		for (int index = 0; index < tableSize; index++) {
			//if the spot has never been used or a record has been deleted
			if ((table[index] != NULL)) {
				//Print every data on the list
				LinkListNode<T> *tempHead = table[index]->head;
				cout << "[";
				while (tempHead != NULL) {
					if (tempHead->data->getKey() != deletedMark) {
						cout << tempHead->data->print() << "->";
					}
					tempHead = tempHead->next;
				}
				cout << "]";
			}
			else {
				cout << "[ ] ";
			}
		}
		cout << endl << endl;
	}

	T find(string key) {
		int index = hash(key);
		if (table[index] != NULL) {
			LinkListNode<T> *tempHead = table[index]->head;
			if ((tempHead != NULL) && (tempHead->data->getKey() != deletedMark)) {
				return getData(index, key);
			}
		}
		return NULL;
	}

	bool insert(T value) {
		int index;
		index = hash(value->getKey());

		//if the spot is empty, or the record has been deleted, or the keys are the same
		if (table[index] == NULL) {
			//Create an empty list
			table[index] = new LinkList<T>;
		}
		// Create a LinkList Node to be able to insert
		LinkListNode<T> *linkListNode = new LinkListNode<T>(value);
		//Insert new node to the list
		table[index]->insertLast(linkListNode);
		return true;
	}

	bool remove(string key) {
		int index = hash(key);

		if (table[index] != NULL) {
			//Iterate over list
			LinkListNode<T> *tempHead = table[index]->head;
			while (tempHead != NULL) {
				if (tempHead->data->getKey() == key) {
					tempHead->data->setKey(deletedMark);
					return true;
				}
				tempHead = tempHead->next;
			}
		}
		return false;
	}
};
#pragma once
