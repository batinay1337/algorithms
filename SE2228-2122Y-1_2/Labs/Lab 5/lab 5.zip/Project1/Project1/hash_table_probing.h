#include <iostream>
#include <cstring>

using namespace std;


template<class T>
class HashTable {
public:
	T **table;
	string deletedMark = "*";
	int tableSize;

	HashTable(int tableSize) {
		this->tableSize = tableSize;
		table = new T *[tableSize];
		for (int index = 0; index < tableSize; index++) {
			table[index] = NULL;
		}
	}
	/*Hash Function: sum of the ASCII codes of the characters % TABLE_SIZE
	Note that returned Hash value is not unique*/
	int hash(string key) {
		int sum = 0;
		for (int index = 0; index < key.length(); ++index) {
			sum = sum + key[index];
		}
		return sum % tableSize;
	}

	//Produces new index in the array
	int rehash(int index) {
		return (index + 1) % tableSize;
	}

	T getData(int index) {
		if (index >= 0 && index < tableSize) {
			return table[index];
		}
		else {
			cout << "Index is out of bound !" << endl;
			return NULL;
		}
	}

	void printHashTable() {
		cout << "Hash Table " << endl;
		for (int index = 0; index < tableSize; index++) {
			//if the spot has never been used or a record has been deleted
			if ((table[index] != NULL) && (table[index]->getKey() != deletedMark)) {
				//Remove print if you override the default operator
				cout << "[" << table[index]->print() << "] ";
			}
			else {
				cout << "[ ] ";
			}
		}
		cout << endl << endl;
	}

	T *find(string key) {
		int index, newIndex;
		index = newIndex = hash(key);
		T *value = table[index];
		/*Because of the way we handle collision, we have to check the
		"equality" of the object with it's "existence"*/
		if ((value != NULL) && (value->getKey() == key)) {
			return value;
		}
		else {
			newIndex = rehash(newIndex);
			/*This implementation uses collision detection with a linear probing solution
			therefore, when you fail to access an item with a calculated hash value, you have to
			search table till you find actual
			Linear probing -> rehash the index value with (i+c mod k) gcd(c,k)= 1,
			where "k" is the table size, "i" is the index and "c" is some constant, typically 1*/
			while (newIndex != index) {
				cout << "Searching with key : " << key << " new index is : " << newIndex << endl;
				if (table[newIndex] != NULL) {
					/* Object comparison, since HashTable can store every type of variable you used
					on your implementation, you have to force the existing data type to carry a specific
					key, that will be used for comparison.*/
					if (table[newIndex]->getKey() == key) {
						return table[newIndex];
					}
				}
				newIndex = rehash(newIndex);
			}
			if (index == newIndex) {
				cout << "Item could not found ! " << endl;
			}
			return NULL;
		}
	}

	bool insert(T *value) {
		int index, newIndex;
		index = hash(value->getKey());

		//if the spot is empty, or the record has been deleted, or the keys are the same
		if ((table[index] == NULL) || (table[index]->getKey() == deletedMark) || (value->getKey() == table[index]->getKey())) {
			table[index] = value;
			return true;
		}
		newIndex = rehash(index);

		while (newIndex != index) {
			if ((table[newIndex] == NULL) || (table[newIndex]->getKey() == deletedMark)) {
				table[newIndex] = value;
				return true;
				//if the keys are the same, update the record
			}
			else if (table[newIndex]->getKey() == value->getKey()) {
				table[newIndex] = value;
				return true;
			}
			newIndex = rehash(newIndex);
		}
		if (index == newIndex) {
			cout << "Could not insert ! " << endl;
		}
		return false;
	}

	bool remove(string key) {
		int index, newIndex;
		T *value;
		index = hash(key);
		value = table[index];

		if ((value != NULL) && (value->getKey() != deletedMark)) {
			if (value->getKey() == key) {
				value->setKey(deletedMark);
				return true;
			}
		}

		newIndex = rehash(index);
		//https://en.wikipedia.org/wiki/Tombstone_(programming)
		while (newIndex != index) {
			if (table[newIndex] != NULL) {
				if (table[newIndex]->getKey() == key) {
					//Mark the data as deleted instead of deleting from array
					table[newIndex]->setKey(deletedMark);
					return true;
				}
			}
			newIndex = rehash(newIndex);
		}
		if (index == newIndex) {
			cout << "Item could not found ! " << endl;
		}
		return false;
	}
}; 
#pragma once
